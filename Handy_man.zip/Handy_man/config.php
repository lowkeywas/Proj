<?php 

$server = "localhost";
$username = "root";
$pass = "";
$db = "handy_man";

$connection = mysqli_connect($server,$username,$pass);

$sql = "create database if not exists $db";
mysqli_query($connection,$sql);

$connection = mysqli_connect($server,$username,$pass,$db);

$sql = "create table if not exists contractor(
    contractor_id int auto_increment primary key,
    full_name varchar(100),
    address varchar(100),
    password varchar(100)
)";

mysqli_query($connection,$sql);

$sql = "create table if not exists handy_man(
	handyman_id int auto_increment primary key,
    full_name varchar(100),
    password varchar(100)
)";

mysqli_query($connection,$sql);

$sql = "
create table if not exists contracts(
	id int auto_increment primary key,
    job_title varchar(100),
    description text,
    contractor_id int not null,
    foreign key(contractor_id) references contractor(contractor_id) on delete cascade,
    handyman_id int not null,
    foreign key(handyman_id) references handy_man(handyman_id) on delete cascade
)
";
    
mysqli_query($connection,$sql);


?>