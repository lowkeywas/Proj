<?php
include('config.php');
if (isset($_GET['reg_id'])) {
    $id = $_GET['reg_id'];
    $sql = "delete from registrar where id = $id";
    mysqli_query($conn, $sql);
    header("location:admin.php");
}

if (isset($_GET['sas_id'])) {
    $id = $_GET['sas_id'];
    $sql = "delete from sas where id = $id";
    mysqli_query($conn, $sql);
    header("location:admin.php");
}


if (isset($_GET['cash_id'])) {
    $id = $_GET['cash_id'];
    $sql = "delete from cashier where id = $id";
    mysqli_query($conn, $sql);
    header("location:admin.php");
}
