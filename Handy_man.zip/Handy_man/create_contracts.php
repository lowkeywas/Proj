<?php include("config.php");?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Dashboard </title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <!-- <link rel="icon" type="image/x-icon" href="./assets/img/favicon/favicon.ico" /> -->

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

    <link rel="stylesheet" href="./assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="./assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="./assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="./assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="./assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="./assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="./assets/vendor/js/helpers.js"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="./assets/js/config.js"></script>
</head>

<body>

    <div style=" display:flex; justify-content:center; " >

        <div class="row p-5" style="width: 600px;">
            <div class="col-md-12">
                <div class="card mb-4">

                    <form action="" method="post">
                        <h5 class="card-header">Create Contract</h5>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Job Title</label>
                                <input name="title" type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter Job Title">
                            </div>
                        
                            <div style="margin-bottom: 50px;">
                                <label for="exampleFormControlTextarea1" class="form-label">Job Description</label>
                                <textarea name="description" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                            </div>
                                <div class="mt-2" style="position: relative;">
                                    <div style="position: absolute; right:0px; bottom:0px;">
                                        <a href="admin.php" type="button" class="btn btn-outline-danger">Cancel</a>
                                        <button type="submit" class="btn btn-outline-success">Submit</button>
                                    </div>
                                </div>
    
                        </div>

                    </form>


                </div>      
            </div>
        </div>
    </div>


</body>

</html>
<?php 

if($_SERVER['REQUEST_METHOD']=="POST"){
    $title = $_POST['title'];
    $description = $_POST['description'];
}

?>