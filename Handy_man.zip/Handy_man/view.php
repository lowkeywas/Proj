<?php 
$name = $_GET['name'];
$image = $_GET['image'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Dashboard </title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <!-- <link rel="icon" type="image/x-icon" href="./assets/img/favicon/favicon.ico" /> -->

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

    <link rel="stylesheet" href="./assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="./assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="./assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="./assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="./assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="./assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="./assets/vendor/js/helpers.js"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="./assets/js/config.js"></script>
</head>

<body class="p-5">

    <div class="row d-flex justify-content-center">
        <!-- Order Statistics -->
        <div class="col-md-6 col-lg-4 col-xl-4 order-0 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex align-items-center justify-content-center pb-0">
                    <div class="card-title mb-0">
                        <h2 class="m-0 me-2">👷‍♂️🏗️<?php echo $name?></h2>
                    </div>
                    <div class="dropdown">

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
                            <a class="dropdown-item" href="javascript:void(0);">Select All</a>
                            <a class="dropdown-item" href="javascript:void(0);">Refresh</a>
                            <a class="dropdown-item" href="javascript:void(0);">Share</a>
                        </div>
                    </div>
                </div>
                <hr>
                <div id="cashier_display" class="card-body" style="height: 400px;">
                        <div class="image-section" style="display: flex; justify-content:center;">
                            <img src=<?php echo $image?> alt="">
                        </div>
                        <hr>
                        <div class="text-section" style=" height:140px; overflow:auto; ">
                            <ul>
                                <li>Plumber</li>
                                <li>Painter</li>
                                <li>Electrician</li>
                                <li>Carpenter</li>
                            </ul>
                            <div style="position: absolute; right:50px; bottom:20px;">
                                <a href="dashboard.php" class="btn btn-primary" >Back</a>
                                <a href="" class="btn btn-success">Hire</a>
                            </div>
                        </div>
                </div>
            </div>
        </div>

        <!--/ Order Statistics -->
    </div>

</body>

</html>